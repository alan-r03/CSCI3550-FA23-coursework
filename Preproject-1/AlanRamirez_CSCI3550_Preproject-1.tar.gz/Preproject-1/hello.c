/*
 * Auth: Alan Ramirez
 * Date: 09-24-23  (Due: 09-24-23)
 * Course: CSCI-3550 (Sec: 002)
 * Desc:  PREPROJECT-01, A Simple "Hello, World" C program.
 */

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(void) {
	printf("Hello World, from Alan Ramirez.\n");
	exit(EXIT_SUCCESS);
} 