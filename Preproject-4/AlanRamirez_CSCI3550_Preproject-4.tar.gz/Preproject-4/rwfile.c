/*
 * Auth: Alan Ramirez
 * Date: 10-27-23  (Due: 9-5-23)
 * Course: CSCI-3550 (Sec: 002)
 * Desc:  PREPROJECT-04, rwfile().
 */

/* 
* necessary include statements for code below 
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* 
* here are global definitions for variables used throughout the 
* program; much easier than passing them through functions 
*/
#define BUFFER_SIZE (100*1024*1024)
int inFile;
int inBytes;
int outFile;
int outBytes;
int fCounter; 
char outFName[80];
char *fBuffer = NULL;
void cleanup(void);
void SIGINT_handler(int sig);

/* 
* the first of two functions aside from main(); this is the cleanup 
* function which closes the in/out files and clears the buffer 
*/
void cleanup(void) {
    if (fBuffer != NULL) {
        /* 
        * free current input buffer 
        */
        free(fBuffer);
        fBuffer = NULL;
    }

    if (inFile >= 0) {
        /* 
        * close current input file 
        */
        close(inFile);
        inFile = -1;
    }

    if (outFile >= 0) {
        /* 
        * close current output file 
        */
        close(outFile);
        outFile = -1;
    }
    return;
}

/* 
* the second function which intercepts and ctrl-c inputs, which would
* normally abruptly end the program; instead, the program will now cleanup()
* the current files then exit with an error statement 
*/
void SIGINT_handler (int sig) {
    fprintf(stderr, "ERROR: Program interrupted.\n");
    cleanup();
    exit(EXIT_FAILURE);
}

/* 
* the final function here, main will do all the reading/writing involved
* with this preproject 
*/
int main(int argc, char *argv[]) { 
    /* 
    * beginning with the 'installation' of our ctrl-c/program interrupt catcher
    */
    signal(SIGINT, SIGINT_handler);

    /*
    * first if statement checks for input arguments, if there is one or more, then continue
    * otherwise, exit
    */
    if (argc > 1) { 
        /*
        * this for loop iterates through all arguments n included in the program execution
        */
        for (fCounter = 1; fCounter < argc; ++fCounter) { 
            /* 
            * first, the program creates and allocates the maximum memory size in the input buffer;
            * the program also checks to see that it successfully allocated the memory for the buffer,
            * otherwise the program will exit
            */
            fBuffer = (char *) malloc(BUFFER_SIZE);
            if (fBuffer == NULL) {
                fprintf(stderr, "ERROR: Could not allocate memory.\n");
                exit(EXIT_FAILURE);
            }
            /*
            * second, the program opens the nth file included in the arguments;
            * the program also checks to see that it successfully opened the file, 
            * otherwise the program will exit
            */
            inFile = open(argv[fCounter], O_RDONLY);
            if (inFile <= 0) {
                fprintf(stderr, "ERROR: Failed to open %s\n", argv[fCounter]);
                cleanup();
                exit(EXIT_FAILURE);
            }
            /*
            * third, the program reads all data from the nth file, then stores it in
            * the input buffer, declared earlier; the program also checks to see that 
            * it successfully read from the file, otherwise the program will exit
            */
            printf("Reading: %s...\n", argv[fCounter]);
            inBytes = read(inFile, fBuffer, BUFFER_SIZE);
            if (inBytes < 0) {
                fprintf(stderr, "ERROR: Unable to read file: %s\n", argv[fCounter]);
                cleanup();
                exit(EXIT_FAILURE);
            }
            /*
            * fourth, the program creates the output file, 'file-n.dat'; the program also 
            * checks to see that it successfully created the output file, otherwise the 
            * program will exit
            */
            sprintf(outFName, "file-%02d.dat", fCounter);
            outFile = open(outFName, O_CREAT|O_WRONLY|O_TRUNC, S_IRUSR|S_IWUSR);
            if (outFile < 0) {
                fprintf(stderr, "ERROR: Could not create: %s\n", outFName);
                cleanup();
                exit(EXIT_FAILURE);
            }
            /*
            * fifth, the program writes to the output file, 'file-n.dat'; the program also
            * checks to see that it successfully wrote all bytes to the output file, 
            * otherwise the program will exit
            */
            printf("Writing: %s\n", outFName);
            outBytes = write(outFile, fBuffer, (size_t) inBytes);
            if (outBytes != inBytes) {
                fprintf(stderr, "ERROR: Error writing to: %s\n", outFName);
                cleanup();
                exit(EXIT_FAILURE);
            }
            /*
            * finally, the program calls cleanup(), freeing up the memory allocated in 
            * the buffer and closing the input/output files
            */
            cleanup();
        }
        /*
        * after successfully iterating through all files, clean up one last time to ensure
        * all memory is freed and exit successfully
        */
        cleanup();
        exit(EXIT_SUCCESS);
    } else { 
        /* 
        * this else statement is executed if there were not enough arguments, meaning no 
        * files were passed to the program execution
        */
        printf("ERROR: Need to supply one or more files as input. Try again.\n"); 
        exit(EXIT_FAILURE);
    }
    return 0; 
}